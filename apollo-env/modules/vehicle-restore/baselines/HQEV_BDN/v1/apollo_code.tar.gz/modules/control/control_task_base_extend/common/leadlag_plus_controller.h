/******************************************************************************
 * Copyright 2019 The Apollo Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/

/**
 * @file lead/lag controller.h
 * @brief Defines the LeadlagController class.
 */

#pragma once

#include "modules/control/control_component/controller_task_base/common/leadlag_controller.h"

#include "modules/control/control_component/proto/leadlag_conf.pb.h"

/**
 * @namespace apollo::control
 * @brief apollo::control
 */
namespace apollo {
namespace control {

/**
* @class LeadlagController
* @brief A lead/lag controller for speed and steering
using defualt integral hold
*/
class LeadlagPlusController : public LeadlagController {
public:
    /**
     * @brief initialize lead/lag controller
     */
    void InitLeadlag();

    /**
     * alpha, beta and tau
     * @param leadlag_conf configuration for leadlag controller
     */
    void SetLeadlagConf(const LeadlagConf &leadlag_conf);
};

}  // namespace control
}  // namespace apollo
