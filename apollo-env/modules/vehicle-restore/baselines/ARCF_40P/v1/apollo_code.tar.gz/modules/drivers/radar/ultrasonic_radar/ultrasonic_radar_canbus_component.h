/******************************************************************************
 * Copyright 2018 The Apollo Authors. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *****************************************************************************/

#pragma once

#include <memory>

#include "modules/drivers/radar/ultrasonic_radar/ultrasonic_radar_canbus.h"

/**
 * @namespace apollo::drivers
 * @brief apollo::drivers
 */
namespace apollo {
namespace drivers {
namespace ultrasonic_radar {

class UltrasonicRadarCanbusComponent : public apollo::cyber::Component<> {
 public:
  UltrasonicRadarCanbusComponent();
  ~UltrasonicRadarCanbusComponent() = default;
  bool Init() override;

 private:
  UltrasonicRadarCanbus utralsonic_radar_canbus_;
  std::shared_ptr<::apollo::cyber::Writer<Ultrasonic>> writer_;
};

CYBER_REGISTER_COMPONENT(UltrasonicRadarCanbusComponent)

}  // namespace ultrasonic_radar
}  // namespace drivers
}  // namespace apollo
