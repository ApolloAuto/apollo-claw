#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PARAMS_DIR="$(cd "$SCRIPT_DIR/../../../perception/data/params" && pwd)"

python3 - "$SCRIPT_DIR" "$PARAMS_DIR" <<'PY'
from pathlib import Path
import re
import sys

conf_dir = Path(sys.argv[1])
params_dir = Path(sys.argv[2])

cameras = [
    ("Narrow.pb.txt", "onsemi_narrow_intrinsics.yaml", "onsemi_narrow"),
    ("Wide.pb.txt", "onsemi_wide_intrinsics.yaml", "onsemi_wide"),
    ("obstacle.pb.txt", "onsemi_obstacle_intrinsics.yaml", "onsemi_obstacle"),
    ("traffic.pb.txt", "onsemi_traffic_intrinsics.yaml", "onsemi_traffic"),
    ("rightforward.pb.txt", "spherical_right_forward_intrinsics.yaml", "spherical_right_forward"),
    ("rightbackward.pb.txt", "spherical_right_backward_intrinsics.yaml", "spherical_right_backward"),
    ("backward.pb.txt", "spherical_backward_intrinsics.yaml", "spherical_backward"),
    ("leftbackward.pb.txt", "spherical_left_backward_intrinsics.yaml", "spherical_left_backward"),
    ("leftforward.pb.txt", "spherical_left_forward_intrinsics.yaml", "spherical_left_forward"),
    ("fisheye_front.pb.txt", "fisheye_front_intrinsics.yaml", "fisheye_front"),
    ("fisheye_left.pb.txt", "fisheye_left_intrinsics.yaml", "fisheye_left"),
    ("fisheye_right.pb.txt", "fisheye_right_intrinsics.yaml", "fisheye_right"),
    ("fisheye_rear.pb.txt", "fisheye_rear_intrinsics.yaml", "fisheye_rear"),
]


def read_value(path, key):
    pattern = re.compile(rf"^\s*{key}\s*:\s*(.+?)\s*$")
    for line in path.read_text().splitlines():
        match = pattern.match(line)
        if match:
            return match.group(1).strip().strip('"')
    raise RuntimeError(f"missing {key} in {path}")


def replace_field(lines, key, value):
    pattern = re.compile(rf"^\s*{key}\s*:")
    changed = False
    result = []
    for line in lines:
        if pattern.match(line):
            result.append(f"{key}: {value}")
            changed = True
        else:
            result.append(line)
    if not changed:
        result.append(f"{key}: {value}")
    return result


for config_name, intrinsic_name, frame_id in cameras:
    config_path = conf_dir / config_name
    intrinsic_path = params_dir / intrinsic_name
    width = read_value(intrinsic_path, "width")
    height = read_value(intrinsic_path, "height")

    lines = config_path.read_text().splitlines()
    lines = replace_field(lines, "frame_id", f'"{frame_id}"')
    lines = replace_field(lines, "width", width)
    lines = replace_field(lines, "height", height)
    config_path.write_text("\n".join(lines) + "\n")
    print(f"updated {config_name}: {width}x{height}, frame_id={frame_id}")
PY
