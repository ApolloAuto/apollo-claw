#!/usr/bin/env bash
# 环境检测 + 常见问题检索提示
set -euo pipefail
BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"      # apollo-install
SKILLS_DIR="$(cd "$BASE_DIR/.." && pwd)"                          # .claude/skills
CYAN='\033[0;36m'; NC='\033[0m'

echo -e "${CYAN}环境检测${NC}"
bash "$SKILLS_DIR/apollo-env-check/scripts/env_check.sh" || true
echo
echo "常见问题检索位置："
echo "  references/knowledge/07_FAQ故障排查/"
echo "  - recover conf failed / 断链"
echo "  - openssl/ssl.h 编译报错"
echo "  - buildtool build -p core 报错"
echo "  - Docker 安装失败"
