# apollo-env Skill 使用文档

> 版本：2.1.0 | 形态：导航入口 + 功能子 skill

---

## 一、简介

`apollo-env` 是 Apollo 环境能力的**导航入口**，本身不承载具体功能，按用户需求路由到对应的功能子 skill。

## 二、子 skill 清单

| 子 skill | 职责 | 命令入口 |
|---|---|---|
| `apollo-env-check` | 环境检测（OS/CPU/内存/磁盘/Docker/网络） | /apollo-env-check |
| `apollo-install` | 安装引导 + 故障诊断 | /apollo-install |
| `apollo-vehicle-restore` | 车型配置切换/恢复/回滚/基线/指纹/感知模型 | /apollo-vehicle-restore |
| `apollo-vehicle-usage` | 车辆使用说明（解锁/启动/充电/常见问题） | /apollo-vehicle-usage |
| `apollo-gnss-config` | GNSS 基站配置/检查 | /apollo-gnss-config |
| `apollo-lidar-config` | 激光雷达配置/检查 | /apollo-lidar-config |
| `apollo-camera-config` | 相机配置/检查/新增 | /apollo-camera-config |

## 三、路由规则

| 用户说 | 路由到 |
|---|---|
| 切换车型配置 / 恢复 / 回滚 / 建立基线 / 车型指纹 | apollo-vehicle-restore |
| 配置 / 检查基站（NTRIP/RTCM） | apollo-gnss-config |
| 配置 / 检查雷达 | apollo-lidar-config |
| 配置 / 检查 / 新增相机 | apollo-camera-config |
| 车辆解锁 / 启动 / 充电 / 常见问题 | apollo-vehicle-usage |
| 检查环境 / 环境状态 | apollo-env-check |
| 安装 Apollo / 编译诊断 | apollo-install |

> **防误判**：动作意图优先于车型关键词。「整成 HQEV 的配置」「切换车型」走 restore；「HQEV 怎么解锁/充电」才走 usage。

## 四、统一命令转发器

`scripts/apollo-env.sh` 保留作为统一命令入口，把子命令转发到对应子 skill 的脚本：

```bash
apollo-env.sh targets              # → apollo-vehicle-restore/registry
apollo-env.sh restore --target X   # → apollo-vehicle-restore/scripts/restore_baseline.sh
apollo-env.sh check                # → apollo-env-check/scripts/env_check.sh
apollo-env.sh gnss check           # → apollo-gnss-config/scripts/check_ntrip_base.py
apollo-env.sh lidar list           # → apollo-lidar-config/config/lidar_templates.yaml
apollo-env.sh camera list          # → apollo-camera-config/config/camera_templates.yaml
```

## 五、保留的通用资源

| 文件 | 作用 |
|---|---|
| `plugins.yaml` | 插件注册表（子 skill 清单 + 命令路由） |
| `scripts/apollo-env.sh` | 统一命令转发器（读注册表动态分发） |
| `references/knowledge_index.md` | 知识库总索引 |
| `references/usage_examples.md` | 命令使用示例 |

## 六、扩展方式

新增能力 = 新增一个子 skill（目录 + SKILL.md + 脚本），并在本 README 和 `SKILL.md` 路由表登记，`apollo-env` 导航入口即可分发。
