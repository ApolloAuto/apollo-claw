---
name: apollo-vehicle-restore
description: Apollo 车型配置切换、参数与代码的基线管理、恢复和回滚。按目标车辆切换/恢复参数、current 软链和 /apollo_workspace/modules 车型代码，支持基线建立、多版本、车型指纹、感知模型下载。触发关键词：切换车型、配置成指定车型、恢复车型、恢复参数、恢复代码、回滚、建立基线、车型指纹、ARCF_40P、HQEV、HQEV_BDN、aem profile use、sample 切换、感知模型下载。命令入口：/apollo-vehicle-restore。
---

# Apollo 车型配置切换、恢复与回滚

管理车型参数/代码基线，支持恢复、回滚、基线建立、车型指纹和感知模型下载。

## 命令

```bash
# 预览差异
bash {BASE_DIR}/scripts/restore_baseline.sh --target ARCF_40P --dry-run

# 恢复（对比后，有差异才恢复，二次确认；--yes 免确认）
bash {BASE_DIR}/scripts/restore_baseline.sh --target ARCF_40P [--yes]

# 回滚
bash {BASE_DIR}/scripts/rollback_baseline.sh --backup <备份目录>

# 建基线（多版本）
bash {BASE_DIR}/scripts/make_baseline.sh --target ARCF_40P [--version v2]

# 车型指纹
bash {BASE_DIR}/scripts/vehicle_stamp.sh scan/verify/stamp/hash

# 下载感知模型（外置，不随基线）
bash {BASE_DIR}/scripts/download_perception_models.sh --target ARCF_40P
```

## 恢复流程

```text
校验指纹/版本 → 校验归档 SHA → 对比参数+代码
→ 无差异提示正常 → 有差异二次确认 → 备份 → 切 sample
→ 恢复参数 → 切回目标 → 恢复代码 → 构建 → 校验
```

## 关键文件

| 文件 | 作用 |
|---|---|
| `baselines/` | 车型基线（ARCF_40P/HQEV/HQEV_BDN） |
| `registry/targets.yaml` | 目标注册表 |
| `scripts/restore_baseline.sh` | 恢复 |
| `scripts/rollback_baseline.sh` | 回滚 |
| `scripts/make_baseline.sh` | 建基线 |
| `scripts/vehicle_stamp.sh` | 车型指纹 |
| `scripts/download_perception_models.sh` | 下载感知模型 |
| `references/restore_format.md` | 恢复格式说明 |

## 感知模型外置

模型权重（约 744M）不随基线，恢复后需重新下载：

```bash
bash {BASE_DIR}/scripts/restore_baseline.sh --target ARCF_40P --yes
bash {BASE_DIR}/scripts/download_perception_models.sh --target ARCF_40P
aem profile use ARCF_40P
```
