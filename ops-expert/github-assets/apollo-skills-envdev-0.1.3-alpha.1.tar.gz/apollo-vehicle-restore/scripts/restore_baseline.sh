#!/usr/bin/env bash
# Restore one vehicle's local parameter and code baseline.
# Both parameters and modules are always compared and handled together.

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
ok() { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠️  $1${NC}"; }
die() { echo -e "${RED}❌ $1${NC}" >&2; exit "${2:-1}"; }
section() { echo -e "\n${CYAN}【$1】${NC}"; }

BASE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
WS="/apollo_workspace"
TARGET=""
DRY_RUN=0
ASSUME_YES=0

usage() {
    cat <<'EOF'
用法:
  restore_baseline.sh --target <目标ID> [--workspace /apollo_workspace] [--dry-run] [--yes]

restore 同时处理目标参数和车型代码，不支持 --scope。
EOF
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        --target) TARGET="${2:-}"; shift 2 ;;
        --workspace) WS="${2:-}"; shift 2 ;;
        --dry-run) DRY_RUN=1; shift ;;
        --yes) ASSUME_YES=1; shift ;;
        -h|--help) usage; exit 0 ;;
        *) die "未知参数: $1" ;;
    esac
done

[[ -n "$TARGET" ]] || { usage >&2; die "必须指定 --target"; }
[[ "$TARGET" =~ ^[A-Za-z0-9_-]+$ ]] || die "目标 ID 含有不允许的字符: $TARGET"
[[ -d "$WS" ]] || die "工作区不存在: $WS"
[[ "$WS" == "/apollo_workspace" ]] || die "本地恢复要求工作区必须是 /apollo_workspace"

PARAM_MANIFEST="$BASE_DIR/baselines/$TARGET/latest/parameters.yaml"
CODE_MANIFEST="$BASE_DIR/baselines/$TARGET/latest/code.yaml"
[[ -f "$PARAM_MANIFEST" ]] || die "缺少参数 manifest: $PARAM_MANIFEST"
[[ -f "$CODE_MANIFEST" ]] || die "缺少代码 manifest: $CODE_MANIFEST"

manifest_value() {
    local file="$1"; local key="$2"
    awk -v key="$key" '$0 ~ "^  " key ":" {sub("^  " key ":[[:space:]]*", ""); gsub(/^"|"$/, ""); print; exit}' "$file"
}

artifact_value() {
    local file="$1"; local key="$2"
    awk -v key="$key" '/^artifact:/{seen=1; next} seen && $0 ~ "^  " key ":" {sub("^  " key ":[[:space:]]*", ""); gsub(/^"|"$/, ""); print; exit}' "$file"
}

# 归档与 manifest 同目录，用 manifest 目录 + 归档文件名解析，避免版本迁移后路径失效
PARAM_ARCHIVE="$(dirname "$PARAM_MANIFEST")/$(basename "$(artifact_value "$PARAM_MANIFEST" path)")"
CODE_ARCHIVE="$(dirname "$CODE_MANIFEST")/$(basename "$(artifact_value "$CODE_MANIFEST" path)")"
PARAM_SHA_EXPECTED="$(artifact_value "$PARAM_MANIFEST" sha256)"
CODE_SHA_EXPECTED="$(artifact_value "$CODE_MANIFEST" sha256)"
[[ -f "$PARAM_ARCHIVE" ]] || die "参数归档不存在: $PARAM_ARCHIVE"
[[ -f "$CODE_ARCHIVE" ]] || die "代码归档不存在: $CODE_ARCHIVE"

check_archive() {
    local file="$1" expected="$2"
    local actual
    actual="$(sha256sum "$file" | awk '{print $1}')"
    [[ "$actual" == "$expected" ]] || die "归档校验失败: $file\n期望: $expected\n实际: $actual"
    ok "归档校验通过: $(basename "$file")"
}

file_manifest() {
    local dir="$1" out="$2"
    (cd "$dir" && find . -type f -printf '%P\n' | LC_ALL=C sort | while IFS= read -r f; do
        printf '%s  %s\n' "$(sha256sum -- "$f" | awk '{print $1}')" "$f"
    done) > "$out"
}

compare_tree() {
    local name="$1" current="$2" archive_root="$3" archive="$4" outdir="$5"
    local expected="$outdir/${name}.baseline.sha" actual="$outdir/${name}.current.sha"
    local diff_file="$outdir/${name}.diff"
    [[ -d "$current" ]] || { echo "missing_tree"; return 0; }
    file_manifest "$archive_root" "$expected"
    file_manifest "$current" "$actual"
    diff -u "$expected" "$actual" > "$diff_file" || true
    if [[ ! -s "$diff_file" ]]; then
        echo "same"
    else
        echo "different"
    fi
}

section "前置检查"
[[ -x "$BASE_DIR/scripts/vehicle_stamp.sh" ]] || die "缺少可执行 vehicle_stamp.sh"
CURRENT_LINK="$WS/profiles/current"
TARGET_PROFILE="$WS/profiles/$TARGET"
[[ -d "$TARGET_PROFILE" ]] || die "目标参数目录不存在: $TARGET_PROFILE"
[[ -L "$CURRENT_LINK" ]] || die "profiles/current 不是软链，停止恢复"
CURRENT_TARGET="$(readlink -f "$CURRENT_LINK")"
[[ "$CURRENT_TARGET" == "$TARGET_PROFILE" ]] || die "当前参数不是目标车型：current -> $CURRENT_TARGET，目标 -> $TARGET_PROFILE"

STAMP_STATUS=0
bash "$BASE_DIR/scripts/vehicle_stamp.sh" verify --target "$TARGET" --workspace "$WS" || STAMP_STATUS=$?
[[ "$STAMP_STATUS" -eq 0 || "$STAMP_STATUS" -eq 4 ]] || die "车型身份或 Apollo 版本校验失败，停止恢复" 3
[[ "$STAMP_STATUS" -eq 4 ]] && warn "目标车型身份一致，但参数内容已漂移，将继续比较基线"

section "归档校验"
check_archive "$PARAM_ARCHIVE" "$PARAM_SHA_EXPECTED"
check_archive "$CODE_ARCHIVE" "$CODE_SHA_EXPECTED"

TMP="$(mktemp -d "/tmp/apollo-env-restore-${TARGET}-XXXXXX")"
cleanup() { rm -rf "$TMP"; }
trap cleanup EXIT
mkdir -p "$TMP/parameter" "$TMP/code"
tar -xzf "$PARAM_ARCHIVE" -C "$TMP/parameter"
tar -xzf "$CODE_ARCHIVE" -C "$TMP/code"
[[ -d "$TMP/parameter/profiles/$TARGET" ]] || die "参数归档根目录不是 profiles/$TARGET"
[[ -d "$TMP/code/modules" ]] || die "代码归档根目录不是 modules"

section "参数与代码对比"
PARAM_RESULT="$(compare_tree parameters "$TARGET_PROFILE" "$TMP/parameter/profiles/$TARGET" "$PARAM_ARCHIVE" "$TMP")"
CODE_RESULT="$(compare_tree code "$WS/modules" "$TMP/code/modules" "$CODE_ARCHIVE" "$TMP")"
[[ "$PARAM_RESULT" == "same" ]] && ok "参数无差异"
[[ "$PARAM_RESULT" != "same" ]] && warn "参数存在差异"
[[ "$CODE_RESULT" == "same" ]] && ok "车型代码无差异"
[[ "$CODE_RESULT" != "same" ]] && warn "车型代码存在差异"

if [[ "$PARAM_RESULT" == "same" && "$CODE_RESULT" == "same" ]]; then
    echo
    ok "当前环境正常：参数和车型代码均与 $TARGET 基线一致"
    exit 0
fi

show_diff_summary() {
    local file="$1" label="$2"
    local added removed
    added="$(grep -c '^+[^+]' "$file" 2>/dev/null || true)"
    removed="$(grep -c '^-[^-]' "$file" 2>/dev/null || true)"
    echo "  $label：新增/缺失或不一致记录 +$added / -$removed"
}
echo
echo "差异摘要："
[[ "$PARAM_RESULT" != "same" ]] && show_diff_summary "$TMP/parameters.diff" "参数"
[[ "$CODE_RESULT" != "same" ]] && show_diff_summary "$TMP/code.diff" "代码"
echo "基线外的当前文件默认保留，不自动删除。"

if [[ "$DRY_RUN" -eq 1 ]]; then
    echo
    echo "dry-run：发现差异，但未切换 profile、未覆盖参数、未覆盖代码、未构建。"
    exit 0
fi

# 恢复前二次确认（真实车辆恢复属高危操作，默认不执行）
echo
echo -e "${CYAN}即将恢复目标：$TARGET${NC}"
[[ "$PARAM_RESULT" != "same" ]] && echo "  - 恢复参数：切 sample → 覆盖参数 → 切回 $TARGET"
[[ "$CODE_RESULT" != "same" ]] && echo "  - 恢复车型代码并执行构建"
echo "  - 备份位置：$WS/.apollo-env/backups/"
if [[ "$ASSUME_YES" -ne 1 ]]; then
    read -r -p "确认执行恢复？[y/N]: " CONFIRM
    if [[ "$CONFIRM" != "y" && "$CONFIRM" != "Y" ]]; then
        echo "已取消，未修改参数和代码。"
        exit 0
    fi
fi

section "备份"
BACKUP="$WS/.apollo-env/backups/$(date +%Y%m%d-%H%M%S)-$TARGET"
mkdir -p "$BACKUP"
cp -a "$TARGET_PROFILE" "$BACKUP/parameters"
cp -a "$WS/modules" "$BACKUP/modules"
readlink "$CURRENT_LINK" > "$BACKUP/current.link"
cp -f "$WS/.workspace.json" "$BACKUP/workspace.json"
[[ -f "$WS/.env" ]] && cp -f "$WS/.env" "$BACKUP/env"
if command -v git >/dev/null 2>&1; then
    (cd "$WS" && git status --short) > "$BACKUP/git-status.txt" || true
fi
ok "备份已创建: $BACKUP"

if [[ "$PARAM_RESULT" != "same" ]]; then
    section "切换临时参数"
    set +e
    (cd "$WS" && aem profile use sample)
    SAMPLE_STATUS=$?
    set -e
    AFTER_SAMPLE=""
    [[ -L "$CURRENT_LINK" ]] && AFTER_SAMPLE="$(readlink -f "$CURRENT_LINK")"
    [[ "$AFTER_SAMPLE" != "$TARGET_PROFILE" ]] || die "sample 切换后 current 仍指向目标参数，停止恢复"
    if [[ "$SAMPLE_STATUS" -ne 0 ]]; then
        warn "aem profile use sample 返回 $SAMPLE_STATUS，但 current 已脱离目标参数，继续"
    else
        ok "current 已切换到临时参数"
    fi

    section "恢复参数"
    tar -xzf "$PARAM_ARCHIVE" -C "$WS"
    ok "参数已恢复到 $TARGET_PROFILE"

    section "切回目标参数"
    set +e
    (cd "$WS" && aem profile use "$TARGET")
    TARGET_PROFILE_STATUS=$?
    set -e
    [[ -L "$CURRENT_LINK" ]] || die "切回后 profiles/current 不是软链"
    [[ "$(readlink -f "$CURRENT_LINK")" == "$TARGET_PROFILE" ]] || die "切回后 current 未指向 $TARGET_PROFILE"
    if [[ "$TARGET_PROFILE_STATUS" -ne 0 ]]; then
        warn "aem profile use $TARGET 返回 $TARGET_PROFILE_STATUS（可能 recover conf failed），但 current 已指向目标，继续"
    else
        ok "current 已指回 $TARGET_PROFILE"
    fi
else
    ok "参数无差异，跳过参数恢复"
fi

if [[ "$CODE_RESULT" != "same" ]]; then
    section "恢复车型代码"
    tar -xzf "$CODE_ARCHIVE" -C "$WS"
    ok "车型代码已恢复到 $WS/modules"

    section "构建验证"
    (cd "$WS" && buildtool build -p modules) || die "代码构建失败，恢复未完成"
    ok "buildtool build -p modules 通过"
else
    ok "车型代码无差异，跳过代码恢复和构建"
fi

section "最终校验"
FINAL_STAMP_STATUS=0
bash "$BASE_DIR/scripts/vehicle_stamp.sh" verify --target "$TARGET" --workspace "$WS" >/dev/null || FINAL_STAMP_STATUS=$?
[[ "$FINAL_STAMP_STATUS" -eq 0 || "$FINAL_STAMP_STATUS" -eq 4 ]] || die "最终车型身份或 Apollo 版本校验失败"
[[ "$FINAL_STAMP_STATUS" -eq 4 ]] && warn "车型和版本正确，但基线外文件仍被保留，参数内容存在可报告漂移"
[[ "$(readlink -f "$CURRENT_LINK")" == "$TARGET_PROFILE" ]] || die "最终 current 软链错误"
ok "参数、车型代码、软链和构建验证完成"
echo "备份位置: $BACKUP"
